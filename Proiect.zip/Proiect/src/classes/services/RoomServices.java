package classes.services;

import classes.data.Room;

public class RoomServices {
    public static String getName(Room room) {
        return room.getName();
    }
    public static Integer getRowNum(Room room) {
        return room.getRowNum();
    }
    public static Integer getColNum(Room room) {
        return room.getColNum();
    }
    public static void printInfo(Room room) {
        room.printInfo();
    }
}

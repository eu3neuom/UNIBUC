package classes.services;

import classes.data.Cinema;
import classes.data.Event;
import classes.data.Movie;
import classes.data.Room;

import java.util.List;

public class CinemaServices {
    public static void addRoom(Cinema cinema, Room room) {
        cinema.addRoom(room);
    }
    public static void addMovie(Cinema cinema, Movie movie) {
        cinema.addMovie(movie);
    }
    public static void addEvent(Cinema cinema, Event event) { cinema.addEvent(event); }
    public static void printAllRooms(Cinema cinema) {
        cinema.printAllRooms();
    }
    public static void printAllMovies(Cinema cinema) {
        cinema.printAllMovies();
    }
    public static void printAllEvents(Cinema cinema) {
        cinema.printAllEvents();
    }
    public static void printAllRoomsWithName(Cinema cinema, String name) {
        cinema.printAllRoomsWithName(name);
    }
    public static void printAllMoviesWithPriceLessThan(Cinema cinema, Integer price) {
        cinema.printAllMoviesWithPriceLessThan(price);
    }
    public static List<Room> getAllRoomsWithName(Cinema cinema, String name) {
        return cinema.getAllRoomsWithName(name);
    }
    public static List<Movie> getAllMoviesWithPriceLessThan(Cinema cinema, Integer price) {
        return cinema.getAllMoviesWithPriceLessThan(price);
    }
    public static List<Room> getRoomList(Cinema cinema) {
        return cinema.getRoomList();
    }
    public static List<Movie> getMovieList(Cinema cinema) {
        return cinema.getMovieList();
    }
    public static List<Event> getEventList(Cinema cinema) {
        return cinema.getEventList();
    }
}

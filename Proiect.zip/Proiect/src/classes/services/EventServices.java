package classes.services;

import classes.data.Event;

public class EventServices {
    public static Integer getMovieId(Event event) {return event.getMovieIdx(); }
    public static Integer getRoomId(Event event) {return event.getRoomIdx();}
    public static Integer getTickets(Event event) {return event.getAvaliableTickets(); }
    public static void printInfo(Event event) {
        event.printInfo();
    }
}

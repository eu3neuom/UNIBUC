package classes.services;

import classes.data.Event;
import classes.data.Movie;
import classes.data.Room;

import java.util.List;

public class EventServices {
    public static Movie getMovie(Event event) {
        return event.getMovie();
    }
    public static Room getRoom(Event event) {
        return event.getRoom();
    }
    public static Boolean hasTicket(Event event, Integer num) {
        return event.hasTicket(num);
    }
    public static List<Integer> avaliableTickets(Event event) {
        return event.avaliableTickets();
    }
    public static void printInfo(Event event) {
        event.printInfo();
    }
}

package classes.services;

import classes.data.Client;
import classes.data.Movie;

public class ClientServices {
    public static Boolean inBuget(Client client, Movie movie) {
        return client.inBuget(movie);
    }
    public static void printInfo(Client client) {
        client.printInfo();
    }
}

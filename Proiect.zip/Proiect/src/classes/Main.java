package classes;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String args[]) {
        List<Room> roomList = new ArrayList<>();
        roomList.add(new Room(3, 5, "Pompeiu"));
        roomList.add(new Room(2, 11, "Titeica"));
        roomList.add(new Room(3, 3, "Haret"));
        roomList.add(new Room(roomList.get(0)));

        for (int i = 0; i < roomList.size(); ++i) {
            System.out.println("Room " + i + ": rows = " + roomList.get(i).getRowNum()
                                            + " cols = " + roomList.get(i).getColNum()
                                            + " name = " + roomList.get(i).getName());
        }

        List<String> genreList = new ArrayList<>();
        genreList.add("Drama");
        genreList.add("Comedy");
        genreList.add("Action");
        genreList.add("Horror");
        genreList.add("Romantic");

        List<String> tagList = new ArrayList<>();
        tagList.add("Blood");
        tagList.add("Violence");
        tagList.add("Fighting");
        tagList.add("Cars");

        List<MovieCategory> movieCategoryList = new ArrayList<>();
        movieCategoryList.add(new MovieCategory(genreList, tagList, 12));
        movieCategoryList.add(new MovieCategory(genreList, tagList, 2));
        movieCategoryList.add(new MovieCategory(genreList, tagList));
        movieCategoryList.add(new MovieCategory(movieCategoryList.get(0)));

        List<Movie> movieList = new ArrayList<>();
        movieList.add(new Movie(movieCategoryList.get(0), "Annabelle", 25));
        movieList.get(0).removeTag("Cars");

        movieList.add(new Movie(movieCategoryList.get(0), "Panda", 125));
        movieList.get(1).removeTag("Blood");
        movieList.get(1).removeTag("Fighting");

        movieList.add(new Movie(movieCategoryList.get(2), "Bomm", 25));
        movieList.get(2).addTag("Musical");

        movieList.add(new Movie(movieCategoryList.get(1), "Jurasik", 225));

        for (int i = 0; i < movieList.size(); ++i) {
            System.out.println("Movie " + i + ": name = " + movieList.get(i).getName()
                                            + " price = " + movieList.get(i).getPrice()
                                            + " genres = " + movieList.get(i).getGenres()
                                            + " tags = " + movieList.get(i).getTags());
        }


    }
}

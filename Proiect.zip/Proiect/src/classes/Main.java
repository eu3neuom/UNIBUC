package classes;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String args[]) {
        Generator gen = new Generator();
        Cinema myCinema = new Cinema();
        List<Client> clientList = new ArrayList<>();

        int clientNum = 5;
        int roomNum = 5;
        int movieNum = 5;
        int eventNum = 13;

        for (int i = 0; i < roomNum; ++i) myCinema.addRoom(gen.getRandomRoom());
        for (int i = 0; i < movieNum; ++i) myCinema.addMovie(gen.getRandomMovie());
        for (int i = 0; i < eventNum; ++i) {
            myCinema.addEvent(gen.getRandomInteger(0, roomNum - 1), gen.getRandomInteger(0, movieNum - 1));
        }
        for (int i = 0; i < clientNum; ++i) clientList.add(gen.getRandomClient());

//        myCinema.printAllRooms();
//        myCinema.printAllMovies();
//        myCinema.printAllEvents();
//        myCinema.printAllRoomsWithName("Pompeiu");
//        myCinema.printAllMoviesWithPriceLessThan(30);
//        myCinema.prinAllMoviesInRoom(myCinema.getRoomList().get(0));

//        for (int i = 0; i < clientNum; ++i) {
//            clientList.get(i).printInfo();
//            for (int j = 0; j < eventNum; ++j) {
//                clientList.get(i).buyTicket(myCinema.getEventList().get(j), j);
//            }
//            clientList.get(i).printInfo();
//            System.out.println();
//
//        }

//        myCinema.printAllEvents();

    }
}

package classes;

import classes.CSV.CSVManager;
import classes.data.*;
import classes.services.CinemaServices;
import classes.utilities.Generator;
import classes.utilities.LoggerUtil;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

public class Main {

    public static void main(String args[]) {
        LoggerUtil log = null;
        try {
            log = new LoggerUtil();
        } catch (IOException e) {
            e.printStackTrace();
            log.severe("Can't create log!");
        }

        log.info("Program started");

        Generator gen = new Generator();
        Cinema myCinema = new Cinema();

        List<Client> clientList = CSVManager.read("client");
        myCinema.initiate();

        log.info("Add room to cinema");
        CinemaServices.addRoom(myCinema, gen.getRandomRoom());

        log.info("Add movie to cinema");
        CinemaServices.addMovie(myCinema, gen.getRandomMovie());

        int roomNum = myCinema.getRoomList().size();
        int movieNum = myCinema.getMovieList().size();
        int clientNum = clientList.size();

        log.info("Add event");
        CinemaServices.addEvent(myCinema, gen.getRandomInteger(0, roomNum - 1), gen.getRandomInteger(0, movieNum - 1));

        log.info("Add client");
        Client client = gen.getRandomClient();
        clientList.add(client);
        CSVManager.write(client);

        log.info("Print all rooms");
        CinemaServices.printAllRooms(myCinema);

        log.info("Print all movies");
        CinemaServices.printAllMovies(myCinema);

        log.info("Print all events");
        CinemaServices.printAllEvents(myCinema);

        log.info("Print all rooms with name");
        CinemaServices.printAllRoomsWithName(myCinema, "Pompeiu");

        log.info("Print all movies with price less than");
        CinemaServices.printAllMoviesWithPriceLessThan(myCinema,30);

        log.info("Print all movies in room");
        CinemaServices.prinAllMoviesInRoom(myCinema, CinemaServices.getRoomList(myCinema).get(0));

//        for (int i = 0; i < clientNum; ++i) {
//            clientList.get(i).printInfo();
//            for (int j = 0; j < eventNum; ++j) {
//                clientList.get(i).buyTicket(myCinema.getEventList().get(j), j);
//            }
//            clientList.get(i).printInfo();
//            System.out.println();
//        }

        log.info("Program ended");
    }
}
package classes;

import classes.CSV.CSVManager;
import classes.data.*;
import classes.services.CinemaServices;
import classes.utilities.Generator;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String args[]) {
        Generator gen = new Generator();
        Cinema myCinema = new Cinema();

        List<Client> clientList = CSVManager.read("client");
        myCinema.initiate();
        int clientNum = 5;
        int roomNum = 5;
        int movieNum = 5;
        int eventNum = 13;

//        for (int i = 0; i < roomNum; ++i) CinemaServices.addRoom(myCinema, gen.getRandomRoom());
//        for (int i = 0; i < movieNum; ++i) CinemaServices.addMovie(myCinema, gen.getRandomMovie());
//        for (int i = 0; i < eventNum; ++i) {
//            CinemaServices.addEvent(myCinema, gen.getRandomInteger(0, roomNum - 1), gen.getRandomInteger(0, movieNum - 1));
//        }
        for (int i = 0; i < clientNum; ++i) {
            Client client = gen.getRandomClient();
            clientList.add(client);
            CSVManager.write(client);
        }
        for (Client cl: clientList) cl.printInfo();

        CinemaServices.printAllRooms(myCinema);
        CinemaServices.printAllMovies(myCinema);
        CinemaServices.printAllEvents(myCinema);
        CinemaServices.printAllRoomsWithName(myCinema, "Pompeiu");
        CinemaServices.printAllMoviesWithPriceLessThan(myCinema,30);
        CinemaServices.prinAllMoviesInRoom(myCinema, CinemaServices.getRoomList(myCinema).get(0));

//        for (int i = 0; i < clientNum; ++i) {
//            clientList.get(i).printInfo();
//            for (int j = 0; j < eventNum; ++j) {
//                clientList.get(i).buyTicket(myCinema.getEventList().get(j), j);
//            }
//            clientList.get(i).printInfo();
//            System.out.println();
//        }

        CinemaServices.printAllEvents(myCinema);
        List <Event> auxi = CSVManager.read("event");
//        for (Room mv : auxi) {
//            mv.printInfo();
//        }
    }
}
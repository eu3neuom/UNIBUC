package classes;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String args[]) {
        List<String> genres = new ArrayList<>();
        List<String> tags = new ArrayList<>();

        genres.add("Drama");
        genres.add("Love");
        tags.add("Blood");

        MovieCategory test = new MovieCategory(genres, tags, 15);
        test.addTag("Fighting");

        MovieInfo mi = new MovieInfo(test, "Cei 4 fantastici", 15);
        MovieInfo mi2 = new MovieInfo(genres, tags, "Cei 2 purcei", 199);


//        MovieCategory test = new MovieCategory();
//
//        System.out.println(test.isCheckedGenre("Drama"));
//        System.out.println(test.hasGenre("Drama"));
//        test.addGenre("Drama");
//        System.out.println(test.hasGenre("Drama"));
//        test.checkGenre("Drama");
//        System.out.println(test.isCheckedGenre("Drama"));
//        test.removeGenre("Drama");
//        System.out.println(test.hasGenre("Drama"));
//        System.out.println(test.isCheckedGenre("Drama"));

//        List<String> list = new ArrayList();
//        list.add("Ana");
//        list.add("Dama");
//        list.add("Bana");
//        list.add("dadvfdc");
//
//
//        Checkbox test = new Checkbox(list, 10);
//        System.out.println(test.getChecked());
//        System.out.println(test.getCheckedOptions());
//        System.out.println(test.getUncheckedOptions());
//        test.checkOption("Dama");
//        System.out.println(test.getChecked());
//        System.out.println(test.getCheckedOptions());
//        System.out.println(test.getUncheckedOptions());

//        System.out.println(test.getSize());
//        System.out.println(test.getMaxChecked());
//        System.out.println(test.findOption("AnA"));
//        test.addOption("AnA");
//        System.out.println(test.getSize());
//        System.out.println(test.getMaxChecked());
//        System.out.println(test.findOption("AnA"));
//        test.removeOption("AnA");
//        System.out.println(test.getSize());
//        System.out.println(test.getMaxChecked());
//        System.out.println(test.findOption("AnA"));
    }
}

package classes;

public class MovieRoom {
    private Room room;

    MovieRoom(Room room) {
        this.room = room;
    }

}

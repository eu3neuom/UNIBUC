package classes;

import java.util.ArrayList;
import java.util.List;

public class MovieRoom {
    private Room room;
    private List<Integer> avaliable = new ArrayList<>();
    private Movie movie;

    MovieRoom(Room room, Movie movie) {
        this.room = new Room(room);
        this.movie = movie;
        for (int i = 1; i <= room.getRowNum() * room.getColNum(); ++i) {
            avaliable.add(i);
        }
    }

    List<Integer> getAvaliableList() {
        return this.avaliable;
    }

    Boolean findSeat(Integer num) {
        return avaliable.contains(num);
    }

    void removeSeat(Integer num) {
        if (findSeat(num)) {
            avaliable.remove(num);
        }
    }
}

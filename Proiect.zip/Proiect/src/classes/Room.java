package classes;

public class Room {
    private Integer rowNum, colNum;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRowNum() {
        return rowNum;
    }

    public Integer getColNum() {
        return colNum;
    }

    Room(Room room) {
        this.rowNum = room.getRowNum();
        this.colNum = room.getColNum();
        this.name = room.getName();
    }

    Room(Integer rowNum, Integer colNum, String name) {
        this.rowNum = rowNum;
        this.colNum = colNum;
        this.name = name;
    }

    void printInfo() {
        System.out.println("Room: rowNum = " + rowNum + "; colNum = " + colNum + "; name = " + name + ";");
    }

    Boolean isEqual(Room room) {
        return ((rowNum == room.getRowNum()) && (colNum == room.getColNum()) && (name == room.getName()));
    }
}

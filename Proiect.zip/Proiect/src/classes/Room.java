package classes;

import java.util.ArrayList;
import java.util.List;

public class Room {
    private Integer rowNum, colNum;
    private String name;
    private List<MovieRoom> timeline = new ArrayList<MovieRoom>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRowNum() {
        return rowNum;
    }

    public Integer getColNum() {
        return colNum;
    }

    Room(Integer rowNum, Integer colNum, String name) {
        this.rowNum = rowNum;
        this.colNum = colNum;
        this.name = name;
    }

    void addMovie(MovieRoom movie) {
        timeline.add(movie);
    }
}

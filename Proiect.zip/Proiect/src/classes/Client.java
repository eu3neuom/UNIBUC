package classes;

import java.util.ArrayList;
import java.util.List;

public class Client extends ClientInfo {
    private String phoneNumber;
    private Integer money;
    private List<Integer> eventNumList = new ArrayList<>();
    private List<Integer> ticketNumList = new ArrayList<>();

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    Client(ClientInfo ci, String phoneNumber, Integer money) {
        super(ci);
        this.phoneNumber = phoneNumber;
        this.money = money;
    }

    Boolean inBuget(Movie movie) {
        return (money >= movie.getPrice());
    }

    void buyTicket(Event event, Integer eventId) {
        List<Integer> avaliable = event.avaliableTickets();
        if (getAge() >= event.getMovie().getAgeRestriction() && !avaliable.isEmpty() && inBuget(event.getMovie())) {
            eventNumList.add(eventId);
            ticketNumList.add(avaliable.get(0));

            event.getTicket(avaliable.get(0));
            money -= event.getMovie().getPrice();
        }
    }

    public void printInfo() {
        super.printInfo();
        System.out.println("Client: phoneNumber = " + phoneNumber + "; money = " + money + ";");
        System.out.println("Event id list: " + eventNumList);
        System.out.println("Ticket id list: " + ticketNumList);
    }
}

package classes;

import java.util.ArrayList;
import java.util.List;

public class Event {
    private Room room;
    private Movie movie;
    private List<Integer> tickets = new ArrayList<>();

    public Movie getMovie() {
        return movie;
    }

    public Room getRoom() {
        return room;
    }

    Event(Movie movie, Room room) {
        this.room = room;
        this.movie = movie;
        for (int i = 1; i <= room.getColNum() * room.getRowNum(); ++i) tickets.add(i);
    }

    Boolean hasTicket(Integer num) {
        return tickets.contains(num);
    }

    void getTicket(Integer num) {
        if (hasTicket(num)) {
            tickets.remove(num);
        }
    }

    List<Integer> avaliableTickets() {
        return tickets;
    }

    void printInfo() {
        System.out.println("Event: tickets = " + tickets);
        room.printInfo();
        movie.printInfo();
    }
}

package classes.GUI;

import classes.data.Cinema;
import classes.data.Event;
import classes.data.Movie;
import classes.data.Room;
import classes.services.CinemaServices;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

class ComboItem {
    private String key;
    private Integer value;

    public ComboItem(String key, Integer value)
    {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString()
    {
        return key;
    }

    public String getKey()
    {
        return key;
    }

    public Integer getValue()
    {
        return value;
    }
}

public class MainGUI {
    public JPanel controllerPanel;
    private JPanel mainPanel;
    private JPanel addRoomPanel;
    private JButton addRoomButton;
    private JButton goBackButton;
    private JSpinner rowNumberSpinner;
    private JSpinner columnNumberSpinner;
    private JTextField roomNameTextField;
    private JButton insertRoomButton;
    private JPanel addMoviePanel;
    private JButton addMovieButton;
    private JTextField movieNameTextField;
    private JTextField genreTextField;
    private JTextField tagTextField;
    private JSpinner ageRestrictionSpinner;
    private JSpinner priceSpinner;
    private JButton goBackButton1;
    private JButton insertMovieButton;
    private JButton addEventButton;
    private JButton showMoviesButton;
    private JButton showEventsButton;
    private JButton showRoomsButton;
    private JPanel showRoomsPanel;
    private JButton goBackButton2;
    private JTextArea roomsTextArea;
    private JPanel shoeMoviesPanel;
    private JButton goBackButton3;
    private JTextArea moviesTextArea;
    private JButton roomsWithNameButton;
    private JPanel roomsWithNamePanel;
    private JButton goBackButton4;
    private JTextField roomsWithNameTextField;
    private JTextArea nameForRoom;
    private JButton searchButton;
    private JButton moviesWithPriceLessButton;
    private JPanel moviePriceLessPanel;
    private JButton goBackButton5;
    private JTextArea moviePriceTextArea;
    private JButton searchButton1;
    private JSpinner priceMovieLessSpinner;
    private JPanel showEventsPanel;
    private JButton goBackButton6;
    private JTextArea showEventsTextArea;
    private JPanel addEventPanel;
    private JButton goBackButton7;
    private JComboBox selectRoomComboBox;
    private JComboBox selectMovieComboBox;
    private JButton insertEvent;

    private void resetAddRoomValues() {
        rowNumberSpinner.setValue(0);
        columnNumberSpinner.setValue(0);
        roomNameTextField.setText("");
    }

    private void changePanel(JPanel newPanel) {
        controllerPanel.removeAll();
        controllerPanel.add(newPanel);
        controllerPanel.repaint();
        controllerPanel.revalidate();
    }
    public MainGUI() {
        addRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(addRoomPanel);
            }
        });
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetAddRoomValues();
                changePanel(mainPanel);
            }
        });
        insertRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String roomName = roomNameTextField.getText();
                Integer rowNum = (Integer) rowNumberSpinner.getValue();
                Integer colNum = (Integer) columnNumberSpinner.getValue();

                CinemaServices.addRoom(myCinema, new Room(rowNum, colNum, roomName));
            }
        });
        addMovieButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(addMoviePanel);
            }
        });
        goBackButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        insertMovieButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String movieName = movieNameTextField.getText();
                String genre = genreTextField.getText();
                String tag = tagTextField.getText();
                Integer price = (Integer) priceSpinner.getValue();
                Integer ageRes = (Integer) ageRestrictionSpinner.getValue();

                CinemaServices.addMovie(myCinema, new Movie(movieName, genre, tag, price, ageRes));
            }
        });
        showRoomsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(showRoomsPanel);

                roomsTextArea.setText("");
                List<Room> roomList = CinemaServices.getRoomList(myCinema);
                for (Room room : roomList) {
                    roomsTextArea.append("Name: " + room.getName() + "; ");
                    roomsTextArea.append("Row number: " + room.getRowNum() + "; ");
                    roomsTextArea.append("Column number: " + room.getColNum() + ";\n");
                }
            }
        });
        goBackButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        showMoviesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(shoeMoviesPanel);

                moviesTextArea.setText("");
                List<Movie> movieList = CinemaServices.getMovieList(myCinema);
                for (Movie movie : movieList) {
                    moviesTextArea.append("Name: " + movie.getName() + "; ");
                    moviesTextArea.append("Genre: " + movie.getGenre() + "; ");
                    moviesTextArea.append("Tag: " + movie.getTag() + "; ");
                    moviesTextArea.append("Price: " + movie.getPrice() + "; ");
                    moviesTextArea.append("Age Restriction: " + movie.getAgeRestriction() + ";\n");
                }
            }
        });
        goBackButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        roomsWithNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(roomsWithNamePanel);
            }
        });
        goBackButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameForRoom.setText("");
                List<Room> roomList = CinemaServices.getAllRoomsWithName(myCinema, roomsWithNameTextField.getText());
                for (Room room : roomList) {
                    nameForRoom.append("Name: " + room.getName() + "; ");
                    nameForRoom.append("Row number: " + room.getRowNum() + "; ");
                    nameForRoom.append("Column number: " + room.getColNum() + ";\n");
                }
            }
        });
        moviesWithPriceLessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(moviePriceLessPanel);
            }
        });
        goBackButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        searchButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moviePriceTextArea.setText("");
                List<Movie> movieList = CinemaServices.getAllMoviesWithPriceLessThan(myCinema, (Integer) priceMovieLessSpinner.getValue());

                for (Movie movie : movieList) {
                    moviePriceTextArea.append("Name: " + movie.getName() + "; ");
                    moviePriceTextArea.append("Genre: " + movie.getGenre() + "; ");
                    moviePriceTextArea.append("Tag: " + movie.getTag() + "; ");
                    moviePriceTextArea.append("Price: " + movie.getPrice() + "; ");
                    moviePriceTextArea.append("Age Restriction: " + movie.getAgeRestriction() + ";\n");
                }

            }
        });
        showEventsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(showEventsPanel);

                showEventsTextArea.setText("");
                List<Event> eventList = CinemaServices.getEventList(myCinema);
                for (Event event : eventList) {
                    showEventsTextArea.append("Room id: " + event.getRoomIdx() + "; ");
                    showEventsTextArea.append("Movie id: " + event.getMovieIdx() + "; ");
                    showEventsTextArea.append("Tickets: " + event.getAvaliableTickets() + ";\n");
                }
            }
        });
        goBackButton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        addEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(addEventPanel);

                selectRoomComboBox.removeAllItems();
                selectMovieComboBox.removeAllItems();
                List<Room> roomList = CinemaServices.getRoomList(myCinema);
                for (int i = 0; i < roomList.size(); ++i) {
                    Room room = roomList.get(i);
                    selectRoomComboBox.addItem(new ComboItem(room.getName(), i));
                }

                List<Movie> movieList = CinemaServices.getMovieList(myCinema);
                for (int i = 0; i < movieList.size(); ++i) {
                    Movie movie = movieList.get(i);
                    selectMovieComboBox.addItem(new ComboItem(movie.getName(), i));
                }
            }
        });
        goBackButton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanel(mainPanel);
            }
        });
        insertEvent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Room> roomList = CinemaServices.getRoomList(myCinema);
                Integer roomIdx = selectRoomComboBox.getSelectedIndex();
                Integer movieIdx = selectMovieComboBox.getSelectedIndex();
                CinemaServices.addEvent(myCinema, new Event(roomIdx, movieIdx, roomList.get(roomIdx).getRowNum() * roomList.get(roomIdx).getColNum()));
            }
        });
    }

    private static Cinema myCinema = new Cinema();

    public static void main(String[] args) {
        myCinema.initiate();

        JFrame frame = new JFrame("Cinema manager");
        frame.setContentPane(new MainGUI().controllerPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(550, 550));
        frame.setResizable(false);
        frame.setVisible(true);
    }
}
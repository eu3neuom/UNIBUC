package classes.utilities;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.FileHandler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class LoggerUtil {
    private static FileHandler fileHandler;
    private static Logger logger = Logger.getLogger("cinema.logger");

    private static class CustomFormatter extends Formatter {
        public String format(LogRecord record) {
            String level = record.getLevel().toString();
            Date currentTime = new Date();
            String action = record.getMessage();
            String name = record.getLoggerName();
            String ret = level + "," + currentTime + "," + action + "," + name + "\n";
            return ret;
        }
    }

    public LoggerUtil() throws IOException {
        fileHandler = new FileHandler("./src/classes/CSV/logger.csv", true);
        fileHandler.setFormatter(new CustomFormatter());
        logger.addHandler(fileHandler);
        logger.setUseParentHandlers(false);
    }
    public void info(String message) {
        logger.info(message);
    }
    public void severe(String message) {
        logger.severe(message);
    }
}

package classes.utilities;

import classes.data.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Generator {
    private String movieNames[] = {"Wonderwoman", "Superman", "Barman", "X-Man", "Teen Titans", "Tau", "Beta", "Anon", "Mr. Robot"};
    private String genresNames[] = {"Drama", "Action", "Horror", "Comedy", "Family", "Romantic", "Kids"};
    private String tagsNames[] = {"Race", "Cars", "Blood", "Shooting", "Violence", "Fighting", "Boxing", "Hacking"};
    private String phoneNumbers[] = {"0745637485", "0789348641", "0713278453", "0789349094", "0734985679", "0790223451", "0771123333"};
    private String clientNames[] = {"Ana", "Alina", "Maria", "Monica", "Roxana", "Dan", "Bobi", "Dorel", "Mircea", "Teodor"};
    private String roomNames[] = {"Pompeiu", "Stoilow", "Knuth", "Morris", "Pratt", "Cauchy", "Haret", "Moisil", "Decebal"};
    private Random rnd = new Random();

    public int getRandomInteger(Integer min, Integer max) {
        if (min > max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        return rnd.nextInt(max - min + 1) + min;
    }

    public ClientInfo getRandomClientInfo() {
        String name = clientNames[getRandomInteger(0, clientNames.length - 1)];
        Integer age = getRandomInteger(5, 100);
        ClientInfo ret = new ClientInfo(name, age);
        return ret;
    }

    public Client getRandomClient() {
        String phoneNumber = phoneNumbers[getRandomInteger(0, phoneNumbers.length - 1)];
        Integer money = getRandomInteger(20, 500);
        Client ret = new Client(getRandomClientInfo(), phoneNumber, money);
        return ret;
    }

    public Room getRandomRoom() {
        Integer rowNum = getRandomInteger(3, 10);
        Integer colNum = getRandomInteger(3, 10);
        String name = roomNames[getRandomInteger(0, roomNames.length - 1)];
        Room ret = new Room(rowNum, colNum, name);
        return ret;
    }

    public MovieCategory getRandomMovieCategory() {
        List<String> genre = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        Integer ageRestriction = getRandomInteger(-1, 18);

        Integer genreNum = getRandomInteger(1, 3);
        for (int i = 0; i < genreNum; ++i) genre.add(genresNames[getRandomInteger(0, genresNames.length - 1)]);
        Integer tagsNum = getRandomInteger(1, 3);
        for (int i = 0; i < tagsNum; ++i) tags.add(tagsNames[getRandomInteger(0, tagsNames.length - 1)]);

        MovieCategory ret = new MovieCategory(genre, tags, ageRestriction);
        return ret;
    }

    public Movie getRandomMovie() {
        String name = movieNames[getRandomInteger(0, movieNames.length - 1)];
        Integer price = getRandomInteger(10, 50);
        Movie ret = new Movie(getRandomMovieCategory(), name, price);
        return ret;
    }

    public Event getRandomEvent() {
        Event ret = new Event(getRandomMovie(), getRandomRoom());
        return ret;
    }
}

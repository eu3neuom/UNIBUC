package classes;

import java.util.ArrayList;
import java.util.List;

public class Checkbox {
    private Integer size;
    private Integer checked = 0;
    private Integer maxChecked;
    private List<String> options = new ArrayList<String>();
    private List<Boolean> checkList = new ArrayList<Boolean>();

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getMaxChecked() {
        return maxChecked;
    }

    public void setMaxChecked(Integer maxChecked) {
        this.maxChecked = maxChecked;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public Integer getChecked() {
        return checked;
    }

    Checkbox() {
        size = 0;
        maxChecked = 1;
    }
    Checkbox(List<String> options) {
        size = options.size();
        maxChecked = 1;
        this.options = options;
        for (int i = 0; i < options.size(); ++i) {
            checkList.add(false);
        }
    }
    Checkbox(List<String> options, Integer maxChecked) {
        size = options.size();
        this.maxChecked = maxChecked;
        this.options = options;
        for (int i = 0; i < options.size(); ++i) {
            checkList.add(false);
        }
    }

    Boolean findOption(String option) {
        return options.contains(option);
    }

    Boolean isChecked(String option) {
        if (findOption(option)) {
            int idx = options.indexOf(option);
            return checkList.get(idx);
        }
        return false;
    }

    void addOption(String option) {
        if (!findOption(option)) {
            options.add(option);
            checkList.add(false);
            ++size;
        }
    }

    void removeOption(String option) {
        if (findOption(option)) {
            int idx = options.indexOf(option);
            if (checkList.get(idx)) {
                --checked;
            }
            options.remove(idx);
            checkList.remove(idx);

            --size;
        }
    }

    void checkOption(String option) {
        if (checked < maxChecked) {
            if (findOption(option)) {
                int idx = options.indexOf(option);
                if (!checkList.get(idx)) {
                    ++checked;
                    checkList.set(idx, true);
                }
            }
        }
    }

    void uncheckOption(String option) {
        if (findOption(option)) {
            int idx = options.indexOf(option);
            if (checkList.get(idx)) {
                --checked;
                checkList.set(idx, false);
            }
        }
    }

    List<String> getCheckedOptions() {
        List<String> ret = new ArrayList<String>();
        for (int i = 0; i < size; ++i) {
            if (checkList.get(i)) {
                ret.add(options.get(i));
            }
        }

        return ret;
    }

    List<String> getUncheckedOptions() {
        List<String> ret = new ArrayList<String>();
        for (int i = 0; i < size; ++i) {
            if (!checkList.get(i)) {
                ret.add(options.get(i));
            }
        }

        return ret;
    }
}

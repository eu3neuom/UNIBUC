package classes;

import java.util.ArrayList;
import java.util.List;

public class MovieCategory {
    private List<String> genres = new ArrayList<String>();
    private List<String> tags = new ArrayList<String>();
    private Integer ageRestriction = -1;

    public List<String> getGenres() {
        return genres;
    }

    public void setGenres(List<String> genres) {
        this.genres = genres;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public Integer getAgeRestriction() {
        return ageRestriction;
    }

    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    Boolean findGenre(String genre) {
        return genres.contains(genre);
    }

    void addGenre(String genre) {
        if (!findGenre(genre)) {
            genres.add(genre);
        }
    }

    void removeGenre(String genre) {
        if (findGenre(genre)) {
            genres.remove(genre);
        }
    }

    Boolean findTag(String tag) {
        return tags.contains(tag);
    }

    void addTag(String tag) {
        if (!findTag(tag)) {
            tags.add(tag);
        }
    }

    void removeTag(String tag) {
        if (findTag(tag)) {
            tags.remove(tag);
        }
    }

    MovieCategory(MovieCategory category) {
        this.genres.addAll(category.getGenres());
        this.tags.addAll(category.getTags());
        this.ageRestriction = category.getAgeRestriction();
    }

    MovieCategory(List<String> genres, List<String> tags) {
        this.genres.addAll(genres);
        this.tags.addAll(tags);
    }

    MovieCategory(List<String> genres, List<String> tags, Integer ageRestriction) {
        this.genres.addAll(genres);
        this.tags.addAll(tags);
        this.ageRestriction = ageRestriction;
    }

//    private Checkbox genres = new Checkbox();
//    private Checkbox ageRestriction = new Checkbox();;
//    private Checkbox tags = new Checkbox();;
//
//    MovieCategory() {
//        genres.setMaxChecked(3);
//        ageRestriction.setMaxChecked(1);
//        tags.setMaxChecked(5);
//    }
//
//    void addGenre(String genre) {
//        genres.addOption(genre);
//    }
//
//    void removeGenre(String genre) {
//        genres.removeOption(genre);
//    }
//
//    void checkGenre(String genre) {
//        genres.checkOption(genre);
//    }
//
//    void uncheckGenre(String genre) {
//        genres.uncheckOption(genre);
//    }
//
//    Boolean hasGenre(String genre) {
//        return genres.findOption(genre);
//    }
//
//    Boolean isCheckedGenre(String genre) {
//        return genres.isChecked(genre);
//    }
//
//    void addAgeRestriction(String restriction) {
//        ageRestriction.addOption(restriction);
//    }
//
//    void removeAgeRestriction(String restriction) {
//        ageRestriction.removeOption(restriction);
//    }
//
//    void checkAgeRestriction(String restriction) {
//        ageRestriction.checkOption(restriction);
//    }
//
//    void uncheckAgeRestriction(String restriction) {
//        ageRestriction.uncheckOption(restriction);
//    }
//
//    Boolean hasAgeRestriction(String restriction) {
//        return ageRestriction.findOption(restriction);
//    }
//
//    Boolean isCheckedAgeRestriction(String restriction) {
//        return ageRestriction.isChecked(restriction);
//    }
//
//    void addTag(String tag) {
//        tags.addOption(tag);
//    }
//
//    void removeTag(String tag) {
//        tags.removeOption(tag);
//    }
//
//    void checkTag(String tag) {
//        tags.checkOption(tag);
//    }
//
//    void uncheckTag(String tag) {
//        tags.uncheckOption(tag);
//    }
//
//    Boolean hasTag(String tag) {
//        return tags.findOption(tag);
//    }
//
//    Boolean isCheckedTag(String tag) {
//        return tags.isChecked(tag);
//    }
}

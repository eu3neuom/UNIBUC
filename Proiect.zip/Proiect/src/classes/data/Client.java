package classes.data;

import java.util.ArrayList;
import java.util.List;

public class Client extends ClientInfo {
    private String phoneNumber;
    private Integer money;
    private List<Integer> eventNumList = new ArrayList<>();
    private List<Integer> ticketNumList = new ArrayList<>();

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    public List<Integer> getEventNumList() {return eventNumList; }
    public List<Integer> getTicketNumList() {return ticketNumList; }

    public Client(ClientInfo ci, String phoneNumber, Integer money) {
        super(ci);
        this.phoneNumber = phoneNumber;
        this.money = money;
    }

    public Client(String name, Integer age, String phoneNumber, Integer money, List<Integer> eventNumList, List<Integer> ticketNumList) {
        super(name, age);
        this.phoneNumber = phoneNumber;
        this.money = money;
        this.eventNumList.addAll(eventNumList);
        this.ticketNumList.addAll(ticketNumList);
    }

    public Boolean inBuget(Movie movie) {
        return (money >= movie.getPrice());
    }

    public void printInfo() {
        super.printInfo();
        System.out.println("Client: phoneNumber = " + phoneNumber + "; money = " + money + ";");
        System.out.println("Event id list: " + eventNumList);
        System.out.println("Ticket id list: " + ticketNumList);
    }
}

package classes.data;

import java.util.ArrayList;
import java.util.List;

public class MovieCategory {
    private List<String> genres = new ArrayList<String>();
    private List<String> tags = new ArrayList<String>();
    private Integer ageRestriction = -1;

    public List<String> getGenres() {
        return genres;
    }

    public List<String> getTags() {
        return tags;
    }

    public Integer getAgeRestriction() {
        return ageRestriction;
    }

    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    Boolean findGenre(String genre) {
        return genres.contains(genre);
    }

    void addGenre(String genre) {
        if (!findGenre(genre)) {
            genres.add(genre);
        }
    }

    void removeGenre(String genre) {
        if (findGenre(genre)) {
            genres.remove(genre);
        }
    }

    Boolean findTag(String tag) {
        return tags.contains(tag);
    }

    void addTag(String tag) {
        if (!findTag(tag)) {
            tags.add(tag);
        }
    }

    void removeTag(String tag) {
        if (findTag(tag)) {
            tags.remove(tag);
        }
    }

    public MovieCategory(MovieCategory category) {
        this.genres.addAll(category.getGenres());
        this.tags.addAll(category.getTags());
        this.ageRestriction = category.getAgeRestriction();
    }

    public MovieCategory(List<String> genres, List<String> tags) {
        this.genres.addAll(genres);
        this.tags.addAll(tags);
    }

    public MovieCategory(List<String> genres, List<String> tags, Integer ageRestriction) {
        this.genres.addAll(genres);
        this.tags.addAll(tags);
        this.ageRestriction = ageRestriction;
    }

    public void printInfo() {
        System.out.println("Movie category: ");
        System.out.println("Genres = " + genres);
        System.out.println("Tags = " + tags);
        System.out.println("Age restriction = " + ageRestriction);
    }
}

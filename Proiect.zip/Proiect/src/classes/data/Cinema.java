package classes.data;

import classes.CSV.CSVManager;

import java.util.ArrayList;
import java.util.List;

public class Cinema {
    private List<Room> roomList = new ArrayList<>();
    private List<Movie> movieList = new ArrayList<>();
    private List<Event> eventList = new ArrayList<>();

    public List<Movie> getMovieList() { return  movieList; }
    public List<Room> getRoomList() {
        return roomList;
    }
    public List<Event> getEventList() { return eventList; }

    public void addRoom(Room room) {
        roomList.add(room);
        CSVManager.write(room);
    }
    public void addMovie(Movie movie) {
        movieList.add(movie);
        CSVManager.write(movie);
    }
    public void addEvent(Integer roomIdx, Integer movieIdx) {
        if (roomIdx >= roomList.size()) return;
        if (movieIdx >= movieList.size()) return;
        Event event = new Event(movieList.get(movieIdx), roomList.get(roomIdx));
        eventList.add(event);
        CSVManager.write(event);
    }

    public void printAllRooms() {
        System.out.println("Cinema rooms are:");
        for (int i = 0; i < roomList.size(); ++i) {
            System.out.println("Room no. " + (i + 1));
            roomList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public void printAllMovies() {
        System.out.println("Cinema movies are:");
        for (int i = 0; i < movieList.size(); ++i) {
            System.out.println("Movie no. " + (i + 1));
            movieList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public void printAllEvents() {
        System.out.println("Cinema events are:");
        for (int i = 0; i < eventList.size(); ++i) {
            System.out.println("Event no. " + (i + 1));
            eventList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public List<Room> getAllRoomsWithName(String name) {
        List<Room> tmp = new ArrayList<>();
        for (Room room : roomList) {
            if (room.getName() == name) {
                tmp.add(room);
            }
        }
        return tmp;
    }
    public void printAllRoomsWithName(String name) {
        List<Room> tmp = getAllRoomsWithName(name);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No room with name '" + name + "' found.");
        }
        System.out.println();
    }

    public List<Movie> getAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = new ArrayList<>();
        for (Movie movie : movieList) {
            if (movie.getPrice() <= price) {
                tmp.add(movie);
            }
        }
        return tmp;
    }
    public void printAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = getAllMoviesWithPriceLessThan(price);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No movies with price less than '" + price + "' found.");
        }
        System.out.println();
    }

    public List<Movie> getAllMoviesInRoom(Room room) {
        List<Movie> tmp = new ArrayList<>();
        for (Event event : eventList) {
            if (event.getRoom().isEqual(room)) {
                tmp.add(event.getMovie());
            }
        }
        return tmp;
    }
    public void prinAllMoviesInRoom(Room room) {
        List<Movie> tmp = getAllMoviesInRoom(room);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No movies in this room found.");
        }
        System.out.println();
    }

    public void initiate() {
        roomList = CSVManager.read("room");
        movieList = CSVManager.read("movie");
    }
}

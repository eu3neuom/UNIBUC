package classes.data;

import classes.CSV.CSVManager;
import classes.DB.DBManager;

import java.util.ArrayList;
import java.util.List;

public class Cinema {
    private List<Room> roomList = new ArrayList<>();
    private List<Movie> movieList = new ArrayList<>();
    private List<Event> eventList = new ArrayList<>();

    public List<Movie> getMovieList() { return  movieList; }
    public List<Room> getRoomList() {
        return roomList;
    }
    public List<Event> getEventList() { return eventList; }

    public void addRoom(Room room) {
        roomList.add(room);
        DBManager.addRoom(room);
    }
    public void addMovie(Movie movie) {
        movieList.add(movie);
        DBManager.addMovie(movie);
    }
    public void addEvent(Event event) {
        eventList.add(event);
        DBManager.addEvent(event);
    }

    public void printAllRooms() {
        System.out.println("Cinema rooms are:");
        for (int i = 0; i < roomList.size(); ++i) {
            System.out.println("Room no. " + (i + 1));
            roomList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public void printAllMovies() {
        System.out.println("Cinema movies are:");
        for (int i = 0; i < movieList.size(); ++i) {
            System.out.println("Movie no. " + (i + 1));
            movieList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public void printAllEvents() {
        System.out.println("Cinema events are:");
        for (int i = 0; i < eventList.size(); ++i) {
            System.out.println("Event no. " + (i + 1));
            eventList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    public List<Room> getAllRoomsWithName(String name) {
        List<Room> tmp = new ArrayList<>();
        for (Room room : roomList) {
            if (room.getName().equals(name)) {
                tmp.add(room);
            }
        }
        return tmp;
    }
    public void printAllRoomsWithName(String name) {
        List<Room> tmp = getAllRoomsWithName(name);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No room with name '" + name + "' found.");
        }
        System.out.println();
    }

    public List<Movie> getAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = new ArrayList<>();
        for (Movie movie : movieList) {
            if (movie.getPrice() <= price) {
                tmp.add(movie);
            }
        }
        return tmp;
    }
    public void printAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = getAllMoviesWithPriceLessThan(price);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No movies with price less than '" + price + "' found.");
        }
        System.out.println();
    }

    public void initiate() {
        roomList = DBManager.getRooms();
        movieList = DBManager.getMovies();
        eventList = DBManager.getEvents();
    }
}

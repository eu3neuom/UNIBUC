package classes.data;

public class Event {
    private Integer roomIdx;
    private Integer movieIdx;
    private Integer avaliableTickets;

    public Event() {};
    public Event(Integer roomIdx, Integer movieIdx, Integer avaliableTickets) {
        this.roomIdx = roomIdx;
        this.movieIdx = movieIdx;
        this.avaliableTickets = avaliableTickets;
    }

    public Integer getAvaliableTickets() {
        return avaliableTickets;
    }

    public void printInfo() {
        System.out.println("Event: tickets = " + avaliableTickets);
    }

    public Integer getRoomIdx() {
        return roomIdx;
    }

    public void setRoomIdx(Integer roomIdx) {
        this.roomIdx = roomIdx;
    }

    public Integer getMovieIdx() {
        return movieIdx;
    }

    public void setMovieIdx(Integer movieIdx) {
        this.movieIdx = movieIdx;
    }
}

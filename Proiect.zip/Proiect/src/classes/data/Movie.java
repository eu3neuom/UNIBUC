package classes.data;

public class Movie {
    private String name;
    private Integer price;
    private String genre;
    private String tag;
    private Integer ageRestriction;

    public Movie() {};
    public Movie(String n, String g, String t, Integer p, Integer a) {
        this.name = n;
        this.genre = g;
        this.tag = t;
        this.price = p;
        this.ageRestriction = a;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }


    public void printInfo() {
        System.out.println("Movie: name = " + name + "; price = " + price + "; genre = " + genre + "; tag = " + tag + "are = " + ageRestriction + ";");
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getAgeRestriction() {
        return ageRestriction;
    }

    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }
}

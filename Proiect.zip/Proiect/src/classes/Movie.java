package classes;

public class Movie extends MovieCategory {
    private String name;
    private Integer price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    Movie(MovieCategory category, String name, Integer price) {
        super(category);
        this.name = name;
        this.price = price;
    }

    void printInfo() {
        System.out.println("Movie: name = " + name + "; price = " + price + ";");
        super.printInfo();
    }
}

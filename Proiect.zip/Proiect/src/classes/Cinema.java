package classes;

import java.util.ArrayList;
import java.util.List;

public class Cinema {
    private List<Room> roomList = new ArrayList<>();

    public List<Room> getRoomList() {
        return roomList;
    }

    void addRoom(Room room) {
        roomList.add(room);
    }

    Cinema() {};

    Cinema(List<Room> roomList) {
        this.roomList.addAll(roomList);
    }
}

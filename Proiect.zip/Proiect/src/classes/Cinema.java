package classes;

public class Cinema {
}

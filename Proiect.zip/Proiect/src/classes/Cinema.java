package classes;

import java.util.ArrayList;
import java.util.List;

public class Cinema {
    private List<Room> roomList = new ArrayList<>();
    private List<Movie> movieList = new ArrayList<>();
    private List<Event> eventList = new ArrayList<>();

    public List<Movie> getMovieList() { return  movieList; }
    public List<Room> getRoomList() {
        return roomList;
    }
    public List<Event> getEventList() { return eventList; }

    void addRoom(Room room) {
        roomList.add(room);
    }
    void addMovie(Movie movie) { movieList.add(movie); }
    void addEvent(Integer roomIdx, Integer movieIdx) {
        if (roomIdx >= roomList.size()) return;
        if (movieIdx >= movieList.size()) return;
        eventList.add(new Event(movieList.get(movieIdx), roomList.get(roomIdx)));
    }

    void printAllRooms() {
        System.out.println("Cinema rooms are:");
        for (int i = 0; i < roomList.size(); ++i) {
            System.out.println("Room no. " + (i + 1));
            roomList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    void printAllMovies() {
        System.out.println("Cinema movies are:");
        for (int i = 0; i < movieList.size(); ++i) {
            System.out.println("Movie no. " + (i + 1));
            movieList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    void printAllEvents() {
        System.out.println("Cinema events are:");
        for (int i = 0; i < eventList.size(); ++i) {
            System.out.println("Event no. " + (i + 1));
            eventList.get(i).printInfo();
            System.out.println();
        }
        System.out.println();
    }

    List<Room> getAllRoomsWithName(String name) {
        List<Room> tmp = new ArrayList<>();
        for (Room room : roomList) {
            if (room.getName() == name) {
                tmp.add(room);
            }
        }
        return tmp;
    }
    void printAllRoomsWithName(String name) {
        List<Room> tmp = getAllRoomsWithName(name);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("Noo room with name '" + name + "' found.");
        }
        System.out.println();
    }

    List<Movie> getAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = new ArrayList<>();
        for (Movie movie : movieList) {
            if (movie.getPrice() <= price) {
                tmp.add(movie);
            }
        }
        return tmp;
    }
    void printAllMoviesWithPriceLessThan(Integer price) {
        List<Movie> tmp = getAllMoviesWithPriceLessThan(price);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No movies with price less than '" + price + "' found.");
        }
        System.out.println();
    }

    List<Movie> getAllMoviesInRoom(Room room) {
        List<Movie> tmp = new ArrayList<>();
        for (Event event : eventList) {
            if (event.getRoom().isEqual(room)) {
                tmp.add(event.getMovie());
            }
        }
        return tmp;
    }
    void prinAllMoviesInRoom(Room room) {
        List<Movie> tmp = getAllMoviesInRoom(room);
        for (int i = 0; i < tmp.size(); ++i) {
            tmp.get(i).printInfo();
            System.out.println();
        }
        if (tmp.isEmpty()) {
            System.out.println("No movies in this room found.");
        }
        System.out.println();
    }
}

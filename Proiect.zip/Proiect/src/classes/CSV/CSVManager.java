package classes.CSV;

import classes.data.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CSVManager {
    public static <T> void write(List<T> objList) {
        if (objList.isEmpty()) return;

        switch (objList.get(0).getClass().getName()) {
            case "classes.data.Room":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/rooms.csv"), Charset.forName("UTF-8"), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);

                    // NAME, ROW_NUM, COL_NUM
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    for(T object: objList) {
                        Room room = (Room) object;
                        printer.printRecord(room.getName(), room.getRowNum(), room.getColNum());
                    }
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Movie":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/movies.csv"), Charset.forName("UTF-8"), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);

                    // NAME, PRICE, AGE_RES, GENRES, TAGS
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    for(T object: objList) {
                        Movie movie = (Movie) object;
                        printer.printRecord(movie.getName(), movie.getPrice(), movie.getAgeRestriction(), movie.getGenres(), movie.getTags());
                    }
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Event":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/events.csv"), Charset.forName("UTF-8"), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);

                    // ROOM, MOVIE, TICKETS
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    for(T object: objList) {
                        Event event = (Event) object;
                        printer.printRecord(event.getRoom(), event.getMovie(), event.avaliableTickets());
                    }
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Client":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/clients.csv"), Charset.forName("UTF-8"), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);


                    // NAME, AGE, PHONE, MONEY, EVENT_NUM, TICKET_NUM
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    for(T object: objList) {
                        Client client = (Client) object;
                        printer.printRecord(client.getName(), client.getAge(), client.getPhoneNumber(), client.getMoney(), client.getEventNumList(), client.getTicketNumList());
                    }
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    public static <T> void write(T object) {
        switch (object.getClass().getName()) {
            case "classes.data.Room":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/rooms.csv"), Charset.forName("UTF-8"), StandardOpenOption.APPEND, StandardOpenOption.CREATE);

                    // NAME, ROW_NUM, COL_NUM
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    Room room = (Room) object;
                    printer.printRecord(room.getName(), room.getRowNum(), room.getColNum());
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Movie":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/movies.csv"), Charset.forName("UTF-8"), StandardOpenOption.APPEND, StandardOpenOption.CREATE);

                    // NAME, PRICE, AGE_RES, GENRES, TAGS
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    Movie movie = (Movie) object;
                    printer.printRecord(movie.getName(), movie.getPrice(), movie.getAgeRestriction(), movie.getGenres(), movie.getTags());
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Event":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/events.csv"), Charset.forName("UTF-8"), StandardOpenOption.APPEND, StandardOpenOption.CREATE);

                    // ROOM, MOVIE, TICKETS
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    Event event = (Event) object;
                    printer.printRecord(event.getRoom(), event.getMovie(), event.avaliableTickets());
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "classes.data.Client":
                try {
                    Writer writer = Files.newBufferedWriter(Paths.get("./src/classes/CSV/clients.csv"), Charset.forName("UTF-8"), StandardOpenOption.APPEND, StandardOpenOption.CREATE);

                    // NAME, AGE, PHONE, MONEY, EVENT_NUM, TICKET_NUM
                    CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
                    Client client = (Client) object;
                    printer.printRecord(client.getName(), client.getAge(), client.getPhoneNumber(), client.getMoney(), client.getEventNumList(), client.getTicketNumList());
                    printer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }
    }
    public static <T> List<T> read(String name) {
        List<T> ret = new ArrayList<T>();

        switch (name) {
            case "room":
                try {
                    BufferedReader reader = Files.newBufferedReader(Paths.get("./src/classes/CSV/rooms.csv"));
                    CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

                    for (CSVRecord record: parser) {
                        Room room = new Room(Integer.parseInt(record.get(1)), Integer.parseInt(record.get(2)), record.get(0));
                        ret.add((T) room);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "movie":
                try {
                    BufferedReader reader = Files.newBufferedReader(Paths.get("./src/classes/CSV/movies.csv"));
                    CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

                    for (CSVRecord record: parser) {
                        List<String> genres = Arrays.asList(record.get(3).substring(1, record.get(3).length() - 1).split("\\s*,\\s*"));
                        List<String> tags = Arrays.asList(record.get(4).substring(1, record.get(4).length() - 1).split("\\s*,\\s*"));
                        MovieCategory mc = new MovieCategory(genres, tags, Integer.parseInt(record.get(2)));
                        Movie movie = new Movie(mc, record.get(0), Integer.parseInt(record.get(1)));
                        ret.add((T) movie);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "event":
                try {
                    BufferedReader reader = Files.newBufferedReader(Paths.get("./src/classes/CSV/events.csv"));
                    CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

                    for (CSVRecord record: parser) {
                        System.out.println(record.get(0));
//                        List<String> genres = Arrays.asList(record.get(3).substring(1, record.get(3).length() - 1).split("\\s*,\\s*"));
//                        List<String> tags = Arrays.asList(record.get(4).substring(1, record.get(4).length() - 1).split("\\s*,\\s*"));
//                        MovieCategory mc = new MovieCategory(genres, tags, Integer.parseInt(record.get(2)));
//                        Movie movie = new Movie(mc, record.get(0), Integer.parseInt(record.get(1)));
//                        ret.add((T) movie);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case "client":
                try {
                    BufferedReader reader = Files.newBufferedReader(Paths.get("./src/classes/CSV/clients.csv"));
                    CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

                    for (CSVRecord record: parser) {

                        // NAME, AGE, PHONE, MONEY, EVENT_NUM, TICKET_NUM
                        String clientName = record.get(0);
                        Integer age = Integer.parseInt(record.get(1));
                        String phone = record.get(2);
                        Integer money = Integer.parseInt(record.get(3));
                        List<String> tmp = Arrays.asList(record.get(4).substring(1, record.get(4).length() - 1).split("\\s*,\\s*"));
                        List<Integer> evNum = new ArrayList<Integer>();
                        if (record.get(4).length() > 2) {
                            for (String str : tmp) {
                                evNum.add(Integer.parseInt(str));
                            }
                        }
                        tmp = Arrays.asList(record.get(5).substring(1, record.get(5).length() - 1).split("\\s*,\\s*"));
                        List<Integer> ticNum = new ArrayList<Integer>();
                        if (record.get(5).length() > 2) {
                            for (String str : tmp) {
                                ticNum.add(Integer.parseInt(str));
                            }
                        }
                        Client client = new Client(clientName, age, phone, money, evNum, ticNum);
                        ret.add((T) client);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }

        return ret;
    }
}

package classes.DB;

import classes.data.Event;
import classes.data.Movie;
import classes.data.Room;
import classes.utilities.ConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBManager {
    public static void addRoom(Room room) {
        String insert = "INSERT INTO rooms(name, rowNum, colNum) VALUES ('" + room.getName() + "', "
                        + room.getRowNum().toString() + ", " + room.getColNum().toString() + ");";

        Connection conn = ConnectionUtil.getDBConnection();
        insertData(conn, insert);
        ConnectionUtil.closeDBConnection(conn);
    }

    public static List<Room> getRooms() {
        String sql = "select * from rooms";

        Connection conn = ConnectionUtil.getDBConnection();
        List<Room> ret = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("name");
                Integer rowNum = rs.getInt("rowNum");
                Integer colNum = rs.getInt("colNum");
                ret.add(new Room(rowNum, colNum, name));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return ret;
    }

    public static void addMovie(Movie movie) {
        String insert = "INSERT INTO movies(name, genre, tag, price, ageRes) VALUES ('" + movie.getName() + "', '"
                + movie.getGenre() + "', '" + movie.getTag() + "', " + movie.getPrice() + ", " + movie.getAgeRestriction() + ");";

        Connection conn = ConnectionUtil.getDBConnection();
        insertData(conn, insert);
        ConnectionUtil.closeDBConnection(conn);
    }

    public static List<Movie> getMovies() {
        String sql = "select * from movies";

        Connection conn = ConnectionUtil.getDBConnection();
        List<Movie> ret = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("name");
                String genre = rs.getString("genre");
                String tag = rs.getString("tag");
                Integer price = rs.getInt("price");
                Integer ageRes = rs.getInt("ageRes");
                ret.add(new Movie(name, genre, tag, price, ageRes));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return ret;
    }

    public static void addEvent(Event event) {
        String insert = "INSERT INTO events(r_id, m_id, tickets) VALUES (" + event.getRoomIdx() + ", " + event.getMovieIdx() + ", " + event.getAvaliableTickets() + ");";

        Connection conn = ConnectionUtil.getDBConnection();
        insertData(conn, insert);
        ConnectionUtil.closeDBConnection(conn);
    }

    public static List<Event> getEvents() {
        String sql = "select * from events";

        Connection conn = ConnectionUtil.getDBConnection();
        List<Event> ret = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Integer r_idx = rs.getInt("r_id");
                Integer m_idx = rs.getInt("m_id");
                Integer tickets = rs.getInt("tickets");
                ret.add(new Event(r_idx, m_idx, tickets));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return ret;
    }

    public static void insertData(Connection connection, String insert) {
        try {
            Statement stmt = connection.createStatement();
            stmt.execute(insert);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

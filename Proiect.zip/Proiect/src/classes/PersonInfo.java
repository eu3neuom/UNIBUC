package classes;

public class PersonInfo {
}
